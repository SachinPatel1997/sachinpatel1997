<?php 



//include ('index.php');
$upload_dir = 'uploads/';
//$conn = mysqli_connect("localhost","root","","crud") or die("Connection Failed");

$stu_name = $_POST['sname']; 
 $stu_address = $_POST['saddress'];
 $stu_class = $_POST['class'];
 $stu_phone = $_POST['sphone'];
 $stu_gender = $_POST['sgender'];
 $stu_subject = $_POST['ssubject'];
 
 $imgName = $_FILES['image']['name'];
		$imgTmp = $_FILES['image']['tmp_name'];
		$imgSize = $_FILES['image']['size'];

  

			$imgExt = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));

			$allowExt  = array('jpeg', 'jpg', 'png', 'gif');

			$userPic = time().'_'.rand(1000,9999).'.'.$imgExt;

			if(in_array($imgExt, $allowExt)){

				if($imgSize < 5000000){
					move_uploaded_file($imgTmp ,$upload_dir.$userPic);
				}else{
					$errorMsg = 'Image too large';
				}
			}else{
				$errorMsg = 'Please select a valid image';
			}
		

            $stu_car = $_POST['scar'];
		 $stu_car = implode(',', $_POST['scar']);


	//	}
	//	}

 
$sql = "INSERT INTO student(sname,saddress,sclass,sphone,sgender,ssubject,image,scar) VALUES ('{$stu_name}','{$stu_address}','{$stu_class}','{$stu_phone}','{$stu_gender}','{$stu_subject}','{$userPic}','{$stu_car}')";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
if($result){
	?>
	<script>
	alert ("Insert Into SuccessFully");
	</script>
	<?php
//	header('Location: http://localhost/CorePhp\New folder\CrudOperation/add.php');
	exit();
}else{
	echo "Could Not SuccessFully";
	//header("Location: http://localhost/CorePhp\New folder\CrudOperation/index.php");
//	exit();
}

mysqli_close($conn);
//header("Location: http://localhost/CorePhp\New folder\CrudOperation/index.php");
?>
