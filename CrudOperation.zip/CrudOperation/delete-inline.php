<?php
include('index.php');
$stu_id = $_GET['id'];

include 'config.php';

$sql = "DELETE FROM student WHERE sid = {$stu_id}";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
if($result){
    ?>
    <script>
    alert("Delete Into Data");
    </script>
    <?php
}else{
    ?>
    <script>
    alert("Could Not Into Data");
    </script>
    <?php
}
//header("Location: http://localhost/CorePhp\New folder\CrudOperation/index.php");
mysqli_close($conn);

?>
