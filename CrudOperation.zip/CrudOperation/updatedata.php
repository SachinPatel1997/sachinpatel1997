<?php
include('index.php');
 $upload_dir = 'uploads/';
$stu_id = $_POST['sid'];
$stu_name = $_POST['sname'];
$stu_address = $_POST['saddress'];
$stu_class = $_POST['sclass'];
$stu_phone = $_POST['sphone'];
$stu_gender = $_POST['sgender'];
$stu_subject = $_POST['ssubject'];


$imgName = $_FILES['image']['name'];
		$imgTmp = $_FILES['image']['tmp_name'];
		$imgSize = $_FILES['image']['size'];

		if($imgName){

			$imgExt = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));

			$allowExt  = array('jpeg', 'jpg', 'png', 'gif');

			$userPic = time().'_'.rand(1000,9999).'.'.$imgExt;

			if(in_array($imgExt, $allowExt)){

				if($imgSize < 5000000){
					unlink($upload_dir.$row['image']);
					move_uploaded_file($imgTmp ,$upload_dir.$userPic);
				}else{
					$errorMsg = 'Image too large';
				}
			}else{
				$errorMsg = 'Please select a valid image';
			}
		}else{

			$userPic = $row['image'];
		}
		$stu_car = $_POST['scar'];
		$stu_car = implode(',', $_POST['scar']);

include 'config.php';

$sql = "UPDATE student SET sname = '{$stu_name}', saddress = '{$stu_address}',sclass = '{$stu_class}', sphone = '{$stu_phone}',sgender = '{$stu_gender}',ssubject = '{$stu_subject}',image = '{$userPic}', scar = '{$stu_car}' WHERE sid = {$stu_id}";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
if($result){
	?>
	<script>
		alert("Update Data Into SuccessFully");
	</script>
	<?php
}
//header("Location: http://localhost/CorePhp\New folder\CrudOperation/index.php");

mysqli_close($conn);

?>
