<?php

include 'header.php';
$upload_dir = 'uploads/';
?>
<div id="main-content">
    <h2>All Records</h2>
    <?php
      include 'config.php';

     $sql = "SELECT * FROM student JOIN studentclass WHERE student.sclass = studentclass.cid";
      $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
     
      if(mysqli_num_rows($result) > 0)  {
    ?>
    <?php
    //include 'config.php';
    //$sql1 = " SELECT * FROM student JOIN studentcar WHERE student.scar = studentcar.carid";
    //$result1 = mysqli_query($conn, $sql1) or die("Query Unsuccessful.");
   // if(mysqli_num_rows($result1) > 0)  {
    ?>
   
    <table id="#example" class="table table-striped table-bordered" style="width:100%"  cellpadding="7px">
        <thead>
        <th>Id</th>
        <th>Name</th>
        <th>Address</th>
        <th>Class</th>
        <th>Phone</th>
        <th>Gender</th>
        <th>Subject</th>
        <th>Image</th>
        <th>Car</th>
        <th>Action</th>
        </thead>
        <tbody>
          <?php
          while($row = mysqli_fetch_assoc($result)){
          ?>
          <?php
       //     while($row1 = mysqli_fetch_assoc($result1)){
          ?>
            <tr>
                <td><?php echo $row['sid']; ?></td>
                <td><?php echo $row['sname']; ?></td>
                <td><?php echo $row['saddress']; ?></td>
                <td><?php echo $row['cname']; ?></td>
                <td><?php echo $row['sphone']; ?></td>
                <td><?php echo $row['sgender']; ?></td>
                <td><?php echo $row['ssubject']; ?></td>
                <td><img class="rounded-circle" src="<?php echo $upload_dir.$row['image'] ?>" height="200"></td>
                <td><?php echo $row['scar']; ?></td>
                <td>
                    <a class="btn btn-primary" href='edit.php?id=<?php echo $row['sid']; ?>'>Edit</a>
                    <a class="btn btn-danger" href='delete-inline.php?id=<?php echo $row['sid']; ?>'>Delete</a>
                </td>
            </tr>
        
          
          <?php } ?>
        </tbody>
    </table>
  <?php }else{
    echo "<h2>No Record Found</h2>";
  }
 // mysqli_close($conn);
  
  
  
  mysqli_close($conn);
  ?>
</div>
</div>
</body>
</html>
