<?php include 'header.php';

$upload_dir = 'uploads/';
error_reporting(0);
 ?>

<div id="main-content">
    <h2>Update Record</h2>
    <?php
    include 'config.php';

    $stu_id = $_GET['id'];

    $sql = "SELECT * FROM student WHERE sid = {$stu_id}";
    $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

    if(mysqli_num_rows($result) > 0)  {
      while($row = mysqli_fetch_assoc($result)){
    ?>
    <form class="post-form" action="updatedata.php" method="post">
      <div class="form-group">
          <label>Name</label>
          <input type="hidden" class="form-control" name="sid" value="<?php echo $row['sid']; ?>"/>
          <input type="text" class="form-control" name="sname" value="<?php echo $row['sname']; ?>"/>
      </div>
      <div class="form-group">
          <label>Address</label>
          <input type="text" class="form-control" name="saddress" value="<?php echo $row['saddress']; ?>"/>
      </div>
      <div class="form-group">
          <label>Class</label>
          <?php
            $sql1 = "SELECT * FROM studentclass";
            $result1 = mysqli_query($conn, $sql1) or die("Query Unsuccessful.");

            if(mysqli_num_rows($result1) > 0)  {
              echo '<select name="sclass" class="form-control">';
              while($row1 = mysqli_fetch_assoc($result1)){
                if($row['sclass'] == $row1['cid']){
                  $select = "selected";
                }else{
                  $select = "";
                }
                echo  "<option {$select} value='{$row1['cid']}'>{$row1['cname']}</option>";
              }
          echo "</select>";
        }
            ?>
      </div>
      <div class="form-group">
          <label>Phone</label>
          <input class="form-control" type="text" name="sphone" value="<?php echo $row['sphone']; ?>"/>
      </div>
      <div class="form-group">
                <label>Gender</label>
                <div class="radio"  class="form-control">
					<label><input type="radio" name="sgender" value="Male"  <?php if($row['sgender']=='Male') {?> checked="checked" <?php } ?> required/>Male &nbsp;</label>
					<label><input type="radio" name="sgender" value="Female" <?php echo $row['sgender']?> <?php if($row['sgender']=='Female') {?> checked="checked" <?php } ?>  />Female</label>
				</div>
        </div>
        <div class="form-group">
            <label>Subjects</label>
                    <label><input class="form-control" type="checkbox" name="ssubject" value="math" <?php echo $row['ssubject']?><?php if($row['ssubject']=='math') {?> checked="checked" 
<?php } ?>/>Maths</label>
                    <label><input  class="form-control" type="checkbox" name="ssubject" value="hindi" <?php echo $row['ssubject']?><?php if($row['ssubject']=='hindi') {?> checked="checked" 
<?php } ?>/>Hindi</label>
                <label><input  class="form-control" type="checkbox" name="ssubject" value="english" <?php echo $row['ssubject']?><?php if($row['ssubject']=='english') {?> checked="checked" 
<?php } ?>/>English</label>
        </div>
        <div class="form-group">
                      <label for="image">Choose Image</label>
                      <img class="rounded-circle" src="<?php echo $upload_dir.$row['image'] ?>" width="100">
                      <input type="file" class="form-control" name="image" value="<?php echo $row['image']; ?>">  
                    </div>

                    Flights on: <br/>
<input  class="form-control" type="checkbox" name="scar[]" value="Daily" <?php echo $row['scar']?><?php if($row['scar']=='Daily') {?> checked="checked" 
<?php } ?>>Daily<br>
<input  class="form-control" type="checkbox" name="scar[]" value="Sunday" <?php echo $row['scar']?><?php if($row['scar']=='Sunday') {?> checked="checked" 
<?php } ?>>Sunday<br>
<input   class="form-control" type="checkbox" name="scar[]" value="Monday" <?php echo $row['scar']?><?php if($row['scar']=='Monday') {?> checked="checked" 
<?php } ?>>Monday<br>
<input class="form-control" type="checkbox" name="scar[]" value="Tuesday" <?php echo $row['scar']?><?php if($row['scar']=='Tuesday') {?> checked="checked" 
<?php } ?>>Tuesday <br>
<input  class="form-control" type="checkbox" name="scar[]" value="Wednesday" <?php echo $row['scar']?><?php if($row['scar']=='Wednesday') {?> checked="checked" 
<?php } ?>>Wednesday<br>
<input class="form-control" type="checkbox" name="scar[]" value="Thursday" <?php echo $row['scar']?><?php if($row['scar']=='Thursday') {?> checked="checked" 
<?php } ?>>Thursday <br>
<input class="form-control" type="checkbox" name="scar[]" value="Friday" <?php echo $row['scar']?><?php if($row['scar']=='Friday') {?> checked="checked" 
<?php } ?>>Friday<br>
<input class="form-control" type="checkbox" name="scar[]" value="Saturday" <?php echo $row['scar']?><?php if($row['scar']=='Saturday') {?> checked="checked" 
<?php } ?>>Saturday <br>
       
      <input class="submit" type="submit" value="Update"/>
    </form>
    <?php
      }
    }
    ?>
</div>
</div>
</body>
</html>
