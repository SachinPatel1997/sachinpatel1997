<?php include ('datatable.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>CRUD</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
 <!--<link rel="stylesheet" href="css/style.css">-->
</head>
<body>
    <div id="wrapper">
        <div id="header">
            <h1>Crud</h1>
        </div>
       <!-- <div id="menu">-->
       <div id="menu">

            <ul>
                <li>
                    <a  class="btn btn-primary" style=" list-style: none;" href="index.php">Home</a>
                </li>
                <li>
                    <a class="btn btn-success" href="add.php">Add</a>
                </li>
                <li>
                    <a class="btn btn-danger" href="update.php">Update</a>
                </li>
                <li>
                    <a  class="btn btn-warning" href="delete.php">Delete</a>
                </li>
            </ul>
</div>
       <!-- </div>-->
