-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 20, 2021 at 07:16 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `sid` int(10) NOT NULL AUTO_INCREMENT,
  `sname` varchar(30) NOT NULL,
  `saddress` varchar(100) NOT NULL,
  `sclass` int(10) NOT NULL,
  `sphone` varchar(10) NOT NULL,
  `sgender` varchar(10) NOT NULL,
  `ssubject` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `scar` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `sname`, `saddress`, `sclass`, `sphone`, `sgender`, `ssubject`, `image`, `scar`) VALUES
(34, 'dfsgvfdsgv', 'fdgfg', 2, '454365436', 'Female', 'math', '1613714607_3792.jpg', 'Monday,Tuesday'),
(35, 'gfgv', 'hbghbg', 1, '4643643636', 'Female', 'math', '1613714826_8585.jpg', 'Sunday,Monday'),
(36, 'dgvfsdgvfsdg', 'gfsgrfg', 1, '567890234', 'Female', 'math', '1613714986_4244.jpg', 'Tuesday,Wednesday'),
(37, 'fdsvfds', 'fggfdgb', 1, '4643612345', 'Female', 'math', '1613715278_8729.jpg', 'Monday,Tuesday,Wednesday'),
(38, 'fhfgbh', 'fgbfgb', 1, '1234567891', 'Female', 'math', '1613715415_6359.jpg', 'Monday,Tuesday'),
(39, 'gvfgvf', ' fgfdg ', 1, '1234567891', 'Female', 'math', '1613715634_3986.jpg', 'Monday,Tuesday'),
(40, 'dfdfg', 'fgbfg', 3, '1234567891', 'Female', 'math', '1613715755_3903.jpg', 'Monday,Tuesday,Wednesday'),
(41, 'fdsgdsfg', 'fghfdhg', 2, '1234567891', 'Female', 'math', '1613715834_4857.jpg', 'Sunday,Monday'),
(42, 'ghgdh', 'gbhfdgfdg', 1, '1234567891', 'Female', 'math', '1613716172_2882.jpg', 'Monday,Tuesday'),
(43, 'dhbghb', 'hbgdhb', 3, '1234567890', 'Female', 'math', '1613716466_1156.jpg', 'Tuesday,Wednesday'),
(44, 'ghnghb', 'hghd', 2, '1234567890', 'Female', 'math', '1613716766_9974.jpg', 'Daily,Sunday,Monday'),
(45, 'nghg', 'hgbfdgb', 1, '1234567890', 'Female', 'math', '1613716833_2468.jpg', 'Sunday,Monday'),
(46, 'jnhjhg', 'ghgh', 2, '1234567890', 'Female', 'math', '1613716905_8871.jpg', 'Sunday,Monday'),
(47, 'jnhjhg', 'ghgh', 2, '1234567890', 'Female', 'math', '1613717091_2323.jpg', 'Sunday,Monday'),
(48, 'jnhjhg', 'ghgh', 2, '1234567890', 'Female', 'math', '1613717097_1078.jpg', 'Sunday,Monday'),
(49, 'gvgfgvf', 'fdgfdg', 3, '1234567891', 'Female', 'math', '1613717125_5829.jpg', 'Tuesday,Wednesday'),
(50, 'gvgfgvf', 'fdgfdg', 3, '1234567891', 'Female', 'math', '1613717173_9386.jpg', 'Tuesday,Wednesday'),
(51, 'gvgfgvf', 'fdgfdg', 3, '1234567891', 'Female', 'math', '1613717276_6335.jpg', 'Tuesday,Wednesday'),
(52, 'fdfd', 'fgf', 2, '1234567891', 'Female', 'math', '1613719618_3229.jpg', 'Sunday'),
(53, 'fdfd', 'fgf', 2, '1234567891', 'Female', 'math', '1613719791_1631.jpg', 'Sunday'),
(54, 'fdfd', 'fgf', 2, '1234567891', 'Female', 'math', '1613719826_8617.jpg', 'Sunday'),
(55, 'bghfdg', 'fgfgv', 1, '1234567890', 'Female', 'math', '1613719869_3744.jpg', 'Monday,Tuesday,Wednesday'),
(56, 'bghfdg', 'fgfgv', 1, '1234567890', 'Female', 'math', '1613719941_9776.jpg', 'Monday,Tuesday,Wednesday'),
(57, 'bghfdg', 'fgfgv', 1, '1234567890', 'Female', 'math', '1613720024_9323.jpg', 'Monday,Tuesday,Wednesday'),
(58, 'bghfdg', 'fgfgv', 1, '1234567890', 'Female', 'math', '1613723241_4903.jpg', 'Monday,Tuesday,Wednesday'),
(59, 'bghfdg', 'fgfgv', 1, '1234567890', 'Female', 'math', '1613723392_6077.jpg', 'Monday,Tuesday,Wednesday'),
(60, 'bghfdg', 'fgfgv', 1, '1234567890', 'Female', 'math', '1613723514_2450.jpg', 'Monday,Tuesday,Wednesday'),
(61, 'gtrtgr', 'grfgrf', 3, '1234567890', 'Male', 'math', '1613729461_8115.jpg', 'Monday,Thursday'),
(62, 'gtrtgr', 'grfgrf', 3, '1234567890', 'Male', 'math', '1613729763_4804.jpg', 'Monday,Thursday'),
(63, 'buiui', 'gvfgv', 1, '5655654654', 'Male', 'math', '1613735337_7280.jpg', 'Monday');

-- --------------------------------------------------------

--
-- Table structure for table `studentclass`
--

DROP TABLE IF EXISTS `studentclass`;
CREATE TABLE IF NOT EXISTS `studentclass` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(15) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentclass`
--

INSERT INTO `studentclass` (`cid`, `cname`) VALUES
(1, 'BCA'),
(2, 'Btech'),
(3, 'Bsc'),
(4, 'Bcom');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
