<?php include 'header.php';

if(isset($_POST['deletebtn'])){

include "config.php";
$stu_id = $_POST['sid'];

$sql = "DELETE FROM student WHERE sid = {$stu_id}";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
if($result){
    ?>
    <script>
    alert("Delete Into Data");
    </script>
    <?php
}else{
    ?>
    <script>
    alert("Could Not Into Data");
    </script>
    <?php
//header("Location: http://localhost/CorePhp\New folder\CrudOperation/index.php");

mysqli_close($conn);

}
?>
<div id="main-content">
    <h2>Delete Record</h2>
    <form class="post-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <div class="form-group">
            <label>Id</label>
            <input type="text" name="sid" />
        </div>
        <input class="submit" type="submit" name="deletebtn" value="Delete" />
    </form>
</div>
</div>
</body>
</html>
