
<?php
//include 'validation.php';
 include 'header.php';
  //include('validation.php'); 
 $upload_dir = 'uploads/';
 ?>
<div id="main-content">
    <h2>Add New Record</h2>
    <form  class="post-form" action="savedata.php"  method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Name</label>
            <input class="form-control"  type="text" name="sname" required="" 
    placeholder="Name" oninvalid="this.setCustomValidity('Please Enter valid Name')"/>
           
        </div>
        <div class="form-group">
            <label>Address</label>
            <input type="text"  class="form-control" name="saddress"  required="" 
    placeholder="Address" oninvalid="this.setCustomValidity('Please Enter valid Address')"/>

        </div>
        <div class="form-group">
            <label>Class</label>
            <select  name="class"  class="form-control"  required="" 
     oninvalid="this.setCustomValidity('Please Enter valid Class')">
                <option value="" selected disabled>Select Class</option>
                <?php
                include 'config.php';

                $sql = "SELECT * FROM studentclass";
                $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

                while($row = mysqli_fetch_assoc($result)){
                ?>
                <option type="checkbox" name="check[]" value="<?php echo $row['cid']; ?>"><?php echo $row['cname']; ?></option>

              <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="phone" name="sphone" class="form-control"  required="" 
    placeholder="Phone" oninvalid="this.setCustomValidity('Please Enter /^[0-9]{10}$/')"/>
        </div>
        <div class="form-group">
                <label>Gender</label>
                <div class="radio" class="form-control">
					<label><input   type="radio" name="sgender" value="Male"  required="" 
    oninvalid="this.setCustomValidity('Please Enter valid Gender')"/>Male</label>
					<label><input type="radio" name="sgender" value="Female"/>Female</label>
				</div>

        </div>
        <div class="form-group">
            <label>Subjects</label>
                    <label><input class="form-control" type="checkbox" name="ssubject" value="math"  required="" 
     oninvalid="this.setCustomValidity('Please Enter valid Maths')"/>Maths</label>
                    <label><input  class="form-control" type="checkbox" name="ssubject" value="hindi"  required="" 
     oninvalid="this.setCustomValidity('Please Enter valid Hindi')"/>Hindi</label>
                <label><input class="form-control" type="checkbox" name="ssubject" value="english"  required="" 
     oninvalid="this.setCustomValidity('Please Enter valid English')"/>English</label>
        </div>
        <div class="form-group">
                      <label for="image">Choose Image</label>
                      <input type="file" class="form-control" name="image" value=""  required="" 
     oninvalid="this.setCustomValidity('Please Enter valid Image')">
                    </div>
                 
            Flights on: <br/>
<input  class="form-control" type="checkbox" name="scar[]" value="Daily" required>Daily<br>
<input class="form-control" type="checkbox" name="scar[]" value="Sunday" required>Sunday<br>
<input class="form-control" type="checkbox" name="scar[]" value="Monday" required>Monday<br>
<input class="form-control" type="checkbox" name="scar[]" value="Tuesday" required>Tuesday <br>
<input  class="form-control" type="checkbox" name="scar[]" value="Wednesday">Wednesday<br>
<input class="form-control" type="checkbox" name="scar[]" value="Thursday">Thursday <br>
<input class="form-control" type="checkbox" name="scar[]" value="Friday">Friday<br>
<input class="form-control" type="checkbox" name="scar[]" value="Saturday">Saturday <br>
       
        <input  type="submit" value="Save" class="btn btn-primary" name="submit"/>
    </form>
</div>
</div>
</body>
</html>

