<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LARAVEL CRUD 7.0 APPLICATION</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
</head>
<body class="bg-light">
    <div class="p-3 mb-2 bg-dark text-white">
        <div class="container">
            <div class="h3">LARAVEL CRUD 7.0 APPLICATION</div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12 text-right mb-5">
                <a href="<?php echo e(route('laptops.create')); ?>" class="btn btn-primary">Add</a>
            </div>
        </div>
        <?php if(Session::has('msg')): ?>
            <div class="col-md-12">
                <div class="alert alert-success"><?php echo e(Session::get('msg')); ?></div>
            </div>
        <?php endif; ?>

        <?php if(Session::has('errormsg')): ?>
            <div class="col-md-12">
                <div class="alert alert-danger"><?php echo e(Session::get('errormsg')); ?></div>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><h5>Laptop/List</h5></div>
                    <div class="card-body">
                    <table class="table">
                        <thead class="thead-dark">
                            <th>Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Created</th>
                            <th width="100">Edit</th>
                            <th width="100">Delete</th>
                        </thead>
                        <?php if($laptops): ?>

                            <?php $__currentLoopData = $laptops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laptop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($laptop->id); ?></td>
                                    <td><?php echo e($laptop->name); ?></td>
                                    <td><?php echo e($laptop->email); ?></td>
                                    <td><?php echo e($laptop->phone); ?></td>
                                    <td><?php echo e($laptop->create_at); ?></td>
                                    <td><a href="<?php echo e(route('laptops.edit',$laptop->id)); ?>" class="btn btn-primary">Edit</a></td>
                                    <td><a href="<?php echo e(url('laptops/destroy/'.$laptop->id)); ?>" class="btn btn-danger" onclick="deletelaptops(<?php echo e($laptop->id); ?>);">Delete</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php else: ?>
                             <tr>
                                <td colspan=6>Add laptops not to addded yet</td>
                             </tr>
                        <?php endif; ?>
                    </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

    
<script type="text/javascript">
function deletelaptops(id) {
  alert("Are You Sure Want To Delete!");
}
</script>
<?php /**PATH C:\wamp64\www\laravelcrudoperation\resources\views/laptops/list.blade.php ENDPATH**/ ?>