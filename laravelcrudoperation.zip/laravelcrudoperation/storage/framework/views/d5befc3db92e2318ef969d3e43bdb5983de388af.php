<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LARAVEL CRUD 7.0 APPLICATION</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
</head>
<body class="bg-light">
    <div class="p-3 mb-2 bg-dark text-white">
        <div class="container">
            <div class="h3">LARAVEL CRUD 7.0 APPLICATION</div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12 text-right mb-5">
                <a href="<?php echo e(route('laptops.create')); ?>" class="btn btn-primary">Add</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><h5>Laptop/Add</h5></div>
                    <div class="card-body">
                        <form action="<?php echo e(route('laptops.store')); ?>" method="POST" id="addLaptops" name="addLaptops">
                            <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" class="form-control<?php echo e(($errors->any && $errors->first('name'))? 'in-valid' : ''); ?>">
                                    <?php if($errors->any()): ?>
                                        <p class="invalid-feedback"><?php echo e($errors->first('name')); ?></p>
                                    <?php endif; ?>
                                </div>

                                      <div class="form-group">
                                    <label for="">Email</label>
                                    <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>" class="form-control<?php echo e(($errors->any && $errors->first('email'))? 'in-valid' : ''); ?>">
                                    <?php if($errors->any()): ?>
                                        <p class="invalid-feedback"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                </div>

                          
                                <div class="form-group">
                                    <label for="">Phone</label>
                                    <input type="text" name="phone" id="phone" value="<?php echo e(old('phone')); ?>" class="form-control<?php echo e(($errors->any && $errors->first('phone'))? 'in-valid' : ''); ?>" placeholder="(+) Phone">
                                    <?php if($errors->any()): ?>
                                        <p class="invalid-feedback"><?php echo e($errors->first('phone')); ?></p>
                                    <?php endif; ?>
                                </div>
                                
                              <!--  <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input">
                                        <label class="custom-file-label">Choose file</label>
                                    </div>
                                </div>-->

                                <div class="form-group">
                                    <button type="submit" name="submit" class="btn btn-primary">Save</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\wamp64\www\laravelcrudoperation\resources\views/laptops/add.blade.php ENDPATH**/ ?>