<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LARAVEL CRUD 7.0 APPLICATION</title>
    <link rel="stylesheet" href="{{asset('/css/bootstrap.min.css')}}">
</head>
<body class="bg-light">
    <div class="p-3 mb-2 bg-dark text-white">
        <div class="container">
            <div class="h3">LARAVEL CRUD 7.0 APPLICATION</div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12 text-right mb-5">
                <a href="{{route('laptops.create')}}" class="btn btn-primary">Add</a>
            </div>
        </div>
        @if(Session::has('msg'))
            <div class="col-md-12">
                <div class="alert alert-success">{{Session::get('msg')}}</div>
            </div>
        @endif

        @if(Session::has('errormsg'))
            <div class="col-md-12">
                <div class="alert alert-danger">{{Session::get('errormsg')}}</div>
            </div>
        @endif

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><h5>Laptop/List</h5></div>
                    <div class="card-body">
                    <table class="table">
                        <thead class="thead-dark">
                            <th>Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Created</th>
                            <th width="100">Edit</th>
                            <th width="100">Delete</th>
                        </thead>
                        @if($laptops)

                            @foreach($laptops as $laptop)
                                <tr>
                                    <td>{{$laptop->id}}</td>
                                    <td>{{$laptop->name}}</td>
                                    <td>{{$laptop->email}}</td>
                                    <td>{{$laptop->phone}}</td>
                                    <td>{{$laptop->create_at}}</td>
                                    <td><a href="{{route('laptops.edit',$laptop->id)}}" class="btn btn-primary">Edit</a></td>
                                    <td><a href="{{url('laptops/destroy/'.$laptop->id)}}" class="btn btn-danger" onclick="deletelaptops({{$laptop->id}});">Delete</a></td>
                                </tr>
                            @endforeach
                             @else
                             <tr>
                                <td colspan=6>Add laptops not to addded yet</td>
                             </tr>
                        @endif
                    </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

    
<script type="text/javascript">
function deletelaptops(id) {
  alert("Are You Sure Want To Delete!");
}
</script>
