<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LARAVEL CRUD 7.0 APPLICATION</title>
    <link rel="stylesheet" href="{{asset('/css/bootstrap.min.css')}}">
</head>
<body class="bg-light">
    <div class="p-3 mb-2 bg-dark text-white">
        <div class="container">
            <div class="h3">LARAVEL CRUD 7.0 APPLICATION</div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12 text-right mb-5">
                <a href="{{route('laptops.index')}}" class="btn btn-primary">Back</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><h5>Laptop/Edit</h5></div>
                    <div class="card-body">
                        <form action="{{route('laptops.update',$laptop->id)}}" method="POST" id="addLaptops" name="addLaptops">
                            @csrf
                            @method('PUT')
                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input type="text" name="name" id="name" value="{{old('name',$laptop->name)}}" class="form-control{{($errors->any && $errors->first('name'))? 'in-valid' : ''}}">
                                    @if($errors->any())
                                        <p class="invalid-feedback">{{$errors->first('name')}}</p>
                                    @endif
                                </div>

                                         <div class="form-group">
                                    <label for="">Email</label>
                                    <input type="text" name="email" id="email" value="{{old('email',$laptop->email)}}" class="form-control{{($errors->any && $errors->first('email'))? 'in-valid' : ''}}">
                                    @if($errors->any())
                                        <p class="invalid-feedback">{{$errors->first('email')}}</p>
                                    @endif
                                </div>

                          
                                <div class="form-group">
                                    <label for="">Phone</label>
                                    <input type="text" name="phone" id="phone" value="{{old('phone',$laptop->phone)}}" class="form-control{{($errors->any && $errors->first('phone'))? 'in-valid' : ''}}" placeholder="(+) Phone">
                                    @if($errors->any())
                                        <p class="invalid-feedback">{{$errors->first('phone')}}</p>
                                    @endif
                                </div>
                                    
                                   
                                
                                <div class="form-group">
                                    <button type="submit" name="submit" class="btn btn-primary">Save</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>