
<?php $__env->startSection('content'); ?>

 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Catalogues</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Categories</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
        <form name="categoryForm" id="categoryForm" <?php if(empty($categorydata['id'])): ?>  action="<?php echo e(url('admin/add-edit-category')); ?>" <?php else: ?>  action="<?php echo e(url('admin/add-edit-category/'.$categorydata['id'])); ?>" <?php endif; ?>  method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title"><?php echo e($title); ?></h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
              <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="category_name">Category Name</label>
                    <input type="text" class="form-control" id="category_name" name="category_name" placeholder="Enter Category Name" <?php if(!empty($categorydata['category_name'])): ?> value="<?php echo e($categorydata['category_name']); ?>" <?php else: ?> value="<?php echo e(old('category_name')); ?>" <?php endif; ?>>
                </div>
               
                <div id="appendcategorieslevel">
                <?php echo $__env->make('admin.categories.append_categories_level', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               </div> 
              </div>
                <!--Form Group-->
                <div class="col-md-6">
                <div class="form-group">
                  <label>Select Section</label>
                  <select name="section_id" id="section_id" class="form-control select2" style="width: 100%;">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $getSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($section->id); ?>" <?php if(!empty($categorydata['section_id']) && $categorydata['section_id'] ==$section->id): ?> selected <?php endif; ?>><?php echo e($section->name); ?></option>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                           
              
                <!-- /.form-group -->
              <div class="form-group">
                  <label for="exampleInputFile">Category Image</label>
                 <div class="input-group">
                      <div class="custom-file">
                    <input type="file" class="custom-file-input" id="category_image" name="category_image">
                    <label class="custom-file-label" for="category_image">Choose file</label>
                </div>
                <div class="input-group-append">
                    <span class="input-group-text" id="">Upload</span>
                </div>
            </div>
        </div>
</div>
</div>
            <div class="row">
              <div class="col-12 col-sm-6">
                <div class="form-group">
                    <label for="category_discount">Category Discount</label>
                    <input type="text" class="form-control" id="category_discount" name="category_discount" placeholder="Enter Category Name"  <?php if(!empty($categorydata['category_discount'])): ?> value="<?php echo e($categorydata['category_discount']); ?>" <?php else: ?> value="<?php echo e(old('category_discount')); ?>" <?php endif; ?>>
                </div>

                 <div class="form-group">
                    <label for="description">Category Description</label>
                    <textarea name="description" id="description" class="form-control" rows="3" cols="10" placeholder="Enter ..."> <?php if(!empty($categorydata['description'])): ?> <?php echo e($categorydata['description']); ?> <?php else: ?> <?php echo e(old('description')); ?> <?php endif; ?></textarea>
                </div>
              </div>
              <!-- /.col -->
              <div class="col-12 col-sm-6">
                <div class="form-group">
                    <label for="url">Category URL</label>                    
                     <input type="text"  class="form-control" name ="url" id="url" placeholder="Enter Category Name"  <?php if(!empty($categorydata['url'])): ?> value="<?php echo e($categorydata['url']); ?>" <?php else: ?> value="<?php echo e(old('url')); ?>" <?php endif; ?>>
                </div>

                   <div class="form-group">
                    <label for="meta_title">Meta Title</label>
                     <textarea id="meta_title" name="meta_title" class="form-control" rows="3" placeholder="Enter ..." ><?php if(!empty($categorydata['meta_title'])): ?> <?php echo e($categorydata['meta_title']); ?> <?php else: ?> <?php echo e(old('meta_title')); ?> <?php endif; ?></textarea>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
               
               <div class="col-12 col-sm-6">
                <div class="form-group">
                    <label for="meta_description">Meta Description</label>
                    <textarea id="meta_description" name="meta_description" class="form-control" rows="3"  placeholder="Enter Category Name" > <?php if(!empty($categorydata['meta_description'])): ?> <?php echo e($categorydata['meta_description']); ?> <?php else: ?> <?php echo e(old('meta_description')); ?> <?php endif; ?></textarea>               
              </div> 
            </div>   
          </div>    
                  <div class="col-12 com-sm-6">
                   <div class="form-group">
                    <label for="meta_keywords">Meta Keywords</label>
                    <textarea name="meta_keywords" id="meta_keywords" rows="3" class="form-control"  placeholder="Enter ..." > <?php if(!empty($categorydata['meta_keywords'])): ?> <?php echo e($categorydata['meta_keywords']); ?> <?php else: ?> <?php echo e(old('meta_keywords')); ?> <?php endif; ?></textarea>
                </div>
              </div>
          
            </div>
          </div>
          <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </div>
    </form>
      </div>
    </section>
  </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel\resources\views/admin/categories/add_edit_category.blade.php ENDPATH**/ ?>