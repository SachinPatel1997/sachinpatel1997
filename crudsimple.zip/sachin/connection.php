<?php
$username = "root";
$password = "";
$servername = "localhost";
$database = "crudpro";


$con = mysqli_connect($servername,$username,$password,$database);
if($con){
    ?>
   <script>
    alert('Connection Successfully');
   </script>
   <?php
}else{
    ?>
    <script>
        alert('no connection');
    </script>
    <?php
}

?>
