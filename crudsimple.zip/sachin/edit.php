<?php
// including the database connection file
include("connection.php");
 
if(isset($_POST['update']))
{    
    $id = $_POST['id'];
    
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $email=$_POST['email'];  
     $phone=$_POST['phone'];
      $degree=$_POST['degree'];    
    
    // checking empty fields
    if(empty($firstname) || empty($lastname) || empty($email) || empty($phone) || empty($degree)) {            
        if(empty($firstname)) {
            echo "<font color='red'>First Name field is empty.</font><br/>";
        }
        
        if(empty($lastname)) {
            echo "<font color='red'>Last Name field is empty.</font><br/>";
        }
        
        if(empty($email)) {
            echo "<font color='red'>Email field is empty.</font><br/>";
        }
                
         if(empty($phone)) {
            echo "<font color='red'>Phone field is empty.</font><br/>";
        }
         if(empty($degree)) {
            echo "<font color='red'>Degree field is empty.</font><br/>";
        }
        
    } else {    
        //updating the table
        $result = mysqli_query($con, "UPDATE student SET firstname='$firstname',lastname='$lastname',email='$email',phone='$phone',degree='$degree' WHERE id=$id");
        
        //redirectig to the display page. In our case, it is index.php
        header("Location: index.php");
    }
}
?>
<?php
//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM student WHERE id=$id");
 
while($res = mysqli_fetch_array($result))
{
    $firstname = $res['firstname'];
    $lastname = $res['lastname'];
    $email = $res['email'];
     $phone = $res['phone'];
      $degree = $res['degree'];
}
?>
<html>
<head>    
    <title>Edit Data</title>
</head>
 
<body>
    <a href="index.php">Home</a>
    <br/><br/>
    
    <form name="form1" method="post" action="edit.php">
        <table border="0">
            <tr>
                <td>First Name</td>
                <td><input type="text" name="firstname" value="<?php echo $firstname;?>"></td>
            </tr>
            <tr>
                <td>last Name</td>
                <td><input type="text" name="lastname" value="<?php echo $lastname;?>"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="text" name="email" value="<?php echo $email;?>"></td>
            </tr>
             <tr>
                <td>Phone</td>
                <td><input type="text" name="phone" value="<?php echo $phone;?>"></td>
            </tr>
             <tr>
                <td>Degree</td>
                <td><input type="text" name="degree" value="<?php echo $degree;?>"></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>