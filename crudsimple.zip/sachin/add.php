<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
    <form action="" method="POST">
  <div class="form-group">
    <label for="exampleInputEmail1">First Name</label>
    <input type="firstname" name="firstname" class="form-control" placeholder="Enter first name"> 
  </div>
   <div class="form-group">
    <label for="exampleInputEmail1">Last Name</label>
    <input type="lastname" name="lastname" class="form-control" placeholder="Enter last name"> 
  </div>
  
   <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" name="email" class="form-control" placeholder="Enter email"> 
  </div>
   <div class="form-group">
    <label for="exampleInputEmail1">Phone</label>
    <input type="phone" name="phone" class="form-control" placeholder="Enter phone"> 
  </div>
 <div class="form-group">
    <label for="exampleInputEmail1">Degree</label>
    <input type="degree" name="degree" class="form-control"  placeholder="Enter degree"> 
  </div>  
 
 
  <button type="submit" name="submit"  class="btn btn-primary">Submit</button>
</form>
</body>
</html>

<scrip src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></scrip>
<?php
    include 'connection.php';
    if(isset($_POST['submit'])){
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $degree = $_POST['degree'];
        
       $insertquery = " insert into student(firstname,lastname,email,phone,degree) values('$firstname','$lastname','$email','$phone','$degree')";
      $result =  mysqli_query($con,$insertquery);
      if($result){
         echo "Insert Into Successfully";
      }else{
       echo  "not insert successfully";
          
           //display success message
        echo "<font color='green'>Data added successfully.";
        echo "<br/><a href='index.php'>View Result</a>"; 
      } 
      
    }
?>