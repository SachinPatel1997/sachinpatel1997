<?php
include("connection.php");
 
//getting id of the data from url
$id = $_GET['id'];
 
//deleting the row from table
$result = mysqli_query($con, "DELETE FROM student WHERE id=$id");
 
//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>