<?php

use Illuminate\Database\Seeder;

class AdminsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
          DB::table('admins')->delete();
        $adminRecords = [
            ['id'=>1,'firstname'=>'sachin','lastname'=>'patel','email'=>'sach1997pat@gmail.com','password'=>'$2y$10$XybYcnpgJWFb.Aatve/NSuULRQpB85Lov4q15V0lP7f1PHZa2FEoq','phone'=>'7567818629',],
        
        ];
           DB::table('admins')->insert($adminRecords);
    }
}
